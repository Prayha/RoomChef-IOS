//
//  ReviewTableViewCell.swift
//  RoomChef
//
//  Created by JHJ on 2020/09/11.
//  Copyright © 2020 RoomChef. All rights reserved.
//

import UIKit
import WebKit

class ReviewTableViewCell: UITableViewCell {

    @IBOutlet weak var myWebView: WKWebView!
    @IBOutlet weak var title: UILabel!
    
}
