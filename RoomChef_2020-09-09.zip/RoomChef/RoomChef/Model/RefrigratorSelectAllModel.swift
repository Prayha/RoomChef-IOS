//
//  RefrigratorSelectAllModel.swift
//  RoomChef
//
//  Created by JHJ on 2020/09/08.
//  Copyright © 2020 RoomChef. All rights reserved.
//

import Foundation

protocol RefrigratorModelProtocol: class {
    func itemDownloaded(items: NSArray)
}

class RefrigratorSelectAllModel: NSObject {
    
    var delegate: RefrigratorModelProtocol!
    let urlPath = URLPATH + "Refrigerator_Select_All.jsp?uSeqno=\(USERSEQNO)"
    
    func downloadItems() { // 2
        let url: URL = URL(string: urlPath)!
        let defaultSession = Foundation.URLSession(configuration: URLSessionConfiguration.default)
        
        let task = defaultSession.dataTask(with: url) {(data, response, error) in
            if error != nil {
                print("Failed to download Data : \(String(describing: error))")
            } else {
                print("Data is downloaded")
                
                self.parseJson(data!)
            }
        }
        
        task.resume()
    }
    
    func parseJson(_ data: Data) {
        var jsonResult = NSArray()
        
        do {
            jsonResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSArray
        } catch let error as NSError {
            print("Json Parse Error : \(error)")
        }
        
        var jsonElement = NSDictionary()
        let locations = NSMutableArray()
        
        for i in 0 ..< jsonResult.count {
            jsonElement = jsonResult[i] as! NSDictionary
            let query = RefrigratorDBModel()
            
            if let rSeqno: String = jsonElement["rSeqno"] as? String,
                let rIngredient = jsonElement["rIngredient"] as? String,
                let rShelfLife = jsonElement["rShelfLife"] as? String,
                let User_uSeqno = jsonElement["User_uSeqno"] as? String {
                
                query.rSeqno = rSeqno
                query.rIngredient = rIngredient
                query.rShelfLife = rShelfLife
                query.User_uSeqno = User_uSeqno
            }
            
            locations.add(query)
        }
        
        DispatchQueue.main.async(execute: {() -> Void in
            self.delegate.itemDownloaded(items: locations)
        })
    }
}
