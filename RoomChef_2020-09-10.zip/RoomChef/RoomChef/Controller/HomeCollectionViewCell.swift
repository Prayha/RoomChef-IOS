//
//  CollectionViewCell.swift
//  RoomChef
//
//  Created by TJ on 2020/09/07.
//  Copyright © 2020 RoomChef. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblSort: UILabel!
}
